
const int gDAC_PIN[10] = {4, 5, 6, 7, 8, 9, 10, 11, 12, 13};

uint16_t gDAC_value;

const int SINE_SAMPLES = 256;   // points per cycle
uint16_t sineTable[SINE_SAMPLES];

void setup() {

  // Init DAC GPIO
  for(int i=0; i<10; i++){
    pinMode(gDAC_PIN[i], OUTPUT);
  }

  // Generate sine lookup table (0–1023)
  for (int i = 0; i < SINE_SAMPLES; i++) {
    float angle = 2.0 * PI * i / SINE_SAMPLES;
    sineTable[i] = (uint16_t)(512 + 511 * sin(angle));
  }

  gDAC_value = 0;
  outputDAC(gDAC_value);
}

void loop() {

  /*
  uint16_t value = analogRead(A1);
  outputDAC(value);
  */

  /*
  // Sawtooth Wave
  for(gDAC_value=0; gDAC_value<1024; gDAC_value++){
    outputDAC(gDAC_value);
    delay(1);
  }
  */

  
  // Sine Wave
  for (int i = 0; i < SINE_SAMPLES; i++) {
    outputDAC(sineTable[i]);
    delayMicroseconds(100);
  }
  
}

void outputDAC(uint16_t value){
  // Slow output
  /*
  for(int i=0; i<10; i++){
    digitalWrite(gDAC_PIN[i], (value >> i) & 0x01);
  }
  */

  // Faster output
  PORTD = (PORTD & 0b00001111) | (value << 4);
  PORTB = value >> 4;
}
